### Fermion to Spin Transforms via Encoding Graphs

This package is meant to make it easy to examine different encodings of fermion operators to qubit qubit operators, and importantly the inverse mappings. See `ez_inv_maps.py` for example usage.

### TODO